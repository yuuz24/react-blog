import dummyImage1 from "./dummy-image-1.png";
import dummyImage2 from "./dummy-image-2.png";
import search from "./search.png";
export { dummyImage1, dummyImage2, search };
